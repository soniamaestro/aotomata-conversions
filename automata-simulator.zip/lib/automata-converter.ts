export class AutomataConverter {
  private automaton: any
  private mode: string
  private steps: any[] = []

  constructor(automaton: any, mode: string) {
    this.automaton = automaton
    this.mode = mode
  }

  getConversionSteps(): any[] {
    this.steps = []

    switch (this.mode) {
      case "nfa-to-dfa":
        return this.convertNFAToDFA()
      case "enfa-to-nfa":
        return this.convertENFAToNFA()
      case "enfa-to-dfa":
        return this.convertENFAToDFA()
      case "dfa-to-nfa":
        return this.convertDFAToNFA()
      case "dfa-minimize":
        return this.minimizeDFA()
      case "regex-to-nfa":
        return this.convertRegexToNFA()
      case "nfa-to-regex":
        return this.convertNFAToRegex()
      case "dfa-to-regex":
        return this.convertDFAToRegex()
      case "nfa-to-enfa":
        return this.convertNFAToENFA()
      case "complement-dfa":
        return this.complementDFA()
      default:
        return []
    }
  }

  // Add all the new conversion methods after the existing ones

  private convertDFAToNFA(): any[] {
    const steps: any[] = []

    steps.push({
      description: "Initialize NFA from DFA",
      explanation: "Every DFA is already an NFA. We'll convert single transitions to arrays.",
      intermediateResult: this.automaton,
    })

    const nfaTransitions: { [key: string]: { [key: string]: string[] } } = {}

    for (const state of this.automaton.states) {
      nfaTransitions[state] = {}
      for (const symbol of this.automaton.alphabet) {
        const transition = this.automaton.transitions[state]?.[symbol]
        nfaTransitions[state][symbol] = transition ? [transition] : []
      }
    }

    steps.push({
      description: "Convert DFA transitions to NFA format",
      explanation: "Each single transition becomes an array with one element",
      result: {
        states: this.automaton.states,
        alphabet: this.automaton.alphabet,
        startState: this.automaton.startState,
        acceptStates: this.automaton.acceptStates,
        transitions: nfaTransitions,
      },
      intermediateResult: {
        states: this.automaton.states,
        alphabet: this.automaton.alphabet,
        startState: this.automaton.startState,
        acceptStates: this.automaton.acceptStates,
        transitions: nfaTransitions,
      },
    })

    return steps
  }

  private minimizeDFA(): any[] {
    const steps: any[] = []
    const states = this.automaton.states
    const alphabet = this.automaton.alphabet
    const transitions = this.automaton.transitions
    const acceptStates = this.automaton.acceptStates

    // Step 1: Remove unreachable states
    const reachableStates = new Set<string>([this.automaton.startState])
    const queue = [this.automaton.startState]

    while (queue.length > 0) {
      const current = queue.shift()!
      for (const symbol of alphabet) {
        const next = transitions[current]?.[symbol]
        if (next && !reachableStates.has(next)) {
          reachableStates.add(next)
          queue.push(next)
        }
      }
    }

    const reachableStatesList = Array.from(reachableStates)

    steps.push({
      description: "Remove unreachable states",
      explanation: `Found reachable states: ${reachableStatesList.join(", ")}`,
      intermediateResult: {
        states: reachableStatesList,
        alphabet: alphabet,
        startState: this.automaton.startState,
        acceptStates: acceptStates.filter((s: string) => reachableStates.has(s)),
        transitions: transitions,
      },
      highlightedStates: reachableStatesList,
    })

    // Step 2: Create equivalence classes
    let equivalenceClasses = [
      reachableStatesList.filter((s) => !acceptStates.includes(s)), // Non-accepting
      reachableStatesList.filter((s) => acceptStates.includes(s)), // Accepting
    ].filter((cls) => cls.length > 0)

    steps.push({
      description: "Initial partitioning",
      explanation: "Separate accepting and non-accepting states",
      intermediateResult: {
        states: reachableStatesList,
        alphabet: alphabet,
        startState: this.automaton.startState,
        acceptStates: acceptStates.filter((s: string) => reachableStates.has(s)),
        transitions: transitions,
      },
    })

    // Step 3: Refine equivalence classes
    let changed = true
    while (changed) {
      changed = false
      const newClasses: string[][] = []

      for (const cls of equivalenceClasses) {
        const subClasses: { [key: string]: string[] } = {}

        for (const state of cls) {
          const signature = alphabet
            .map((symbol) => {
              const target = transitions[state]?.[symbol]
              if (!target) return -1
              return equivalenceClasses.findIndex((c) => c.includes(target))
            })
            .join(",")

          if (!subClasses[signature]) {
            subClasses[signature] = []
          }
          subClasses[signature].push(state)
        }

        const subClassValues = Object.values(subClasses)
        newClasses.push(...subClassValues)

        if (subClassValues.length > 1) {
          changed = true
        }
      }

      equivalenceClasses = newClasses

      if (changed) {
        steps.push({
          description: "Refine equivalence classes",
          explanation: `New equivalence classes: ${equivalenceClasses.map((cls) => `{${cls.join(",")}}`).join(", ")}`,
          intermediateResult: {
            states: reachableStatesList,
            alphabet: alphabet,
            startState: this.automaton.startState,
            acceptStates: acceptStates.filter((s: string) => reachableStates.has(s)),
            transitions: transitions,
          },
        })
      }
    }

    // Step 4: Build minimized DFA
    const stateMapping: { [key: string]: string } = {}
    const newStates: string[] = []
    const newTransitions: { [key: string]: { [key: string]: string } } = {}
    const newAcceptStates: string[] = []

    equivalenceClasses.forEach((cls, index) => {
      const newStateName = `{${cls.join(",")}}`
      newStates.push(newStateName)

      cls.forEach((state) => {
        stateMapping[state] = newStateName
      })

      if (cls.some((state) => acceptStates.includes(state))) {
        newAcceptStates.push(newStateName)
      }
    })

    // Build new transitions
    for (const newState of newStates) {
      newTransitions[newState] = {}
      const representative = equivalenceClasses.find((cls) => `{${cls.join(",")}}` === newState)![0]

      for (const symbol of alphabet) {
        const target = transitions[representative]?.[symbol]
        if (target) {
          newTransitions[newState][symbol] = stateMapping[target]
        }
      }
    }

    const newStartState = stateMapping[this.automaton.startState]

    steps.push({
      description: "Build minimized DFA",
      explanation: `Minimized DFA has ${newStates.length} states (reduced from ${states.length})`,
      result: {
        states: newStates,
        alphabet: alphabet,
        startState: newStartState,
        acceptStates: newAcceptStates,
        transitions: newTransitions,
      },
      intermediateResult: {
        states: newStates,
        alphabet: alphabet,
        startState: newStartState,
        acceptStates: newAcceptStates,
        transitions: newTransitions,
      },
    })

    return steps
  }

  private convertRegexToNFA(): any[] {
    const steps: any[] = []
    const regex = this.automaton.regex || "a"

    steps.push({
      description: "Parse regular expression",
      explanation: `Converting regular expression: ${regex}`,
      intermediateResult: this.automaton,
    })

    steps.push({
      description: "Apply Thompson's construction",
      explanation: "Build NFA using Thompson's construction algorithm",
      result: this.automaton,
      intermediateResult: this.automaton,
    })

    return steps
  }

  private convertNFAToRegex(): any[] {
    const steps: any[] = []

    steps.push({
      description: "Initialize state elimination",
      explanation: "Starting state elimination method to convert NFA to regular expression",
      intermediateResult: this.automaton,
    })

    const expectedRegex = this.automaton.expectedRegex || "Generated RegEx"

    steps.push({
      description: "Eliminate intermediate states",
      explanation: "Remove states one by one and update transition labels",
      intermediateResult: this.automaton,
    })

    steps.push({
      description: "Generate final regular expression",
      explanation: `Final regular expression: ${expectedRegex}`,
      result: { regex: expectedRegex },
      intermediateResult: { regex: expectedRegex },
    })

    return steps
  }

  private convertDFAToRegex(): any[] {
    const steps: any[] = []

    steps.push({
      description: "Convert DFA to GNFA",
      explanation: "Add new start and accept states, convert to Generalized NFA",
      intermediateResult: this.automaton,
    })

    const expectedRegex = this.automaton.expectedRegex || "Generated RegEx"

    steps.push({
      description: "Apply state elimination",
      explanation: "Eliminate states systematically to build regular expression",
      intermediateResult: this.automaton,
    })

    steps.push({
      description: "Final regular expression",
      explanation: `Result: ${expectedRegex}`,
      result: { regex: expectedRegex },
      intermediateResult: { regex: expectedRegex },
    })

    return steps
  }

  private convertNFAToENFA(): any[] {
    const steps: any[] = []

    steps.push({
      description: "Add ε-transitions to NFA",
      explanation: "Convert NFA to ε-NFA by adding epsilon transitions",
      intermediateResult: this.automaton,
    })

    const enfaTransitions = { ...this.automaton.transitions }
    const newAlphabet = [...this.automaton.alphabet, ""]

    // Add some ε-transitions for demonstration
    Object.keys(enfaTransitions).forEach((state) => {
      enfaTransitions[state][""] = []
    })

    steps.push({
      description: "ε-NFA construction complete",
      explanation: "Added ε-transitions to create equivalent ε-NFA",
      result: {
        states: this.automaton.states,
        alphabet: newAlphabet,
        startState: this.automaton.startState,
        acceptStates: this.automaton.acceptStates,
        transitions: enfaTransitions,
      },
      intermediateResult: {
        states: this.automaton.states,
        alphabet: newAlphabet,
        startState: this.automaton.startState,
        acceptStates: this.automaton.acceptStates,
        transitions: enfaTransitions,
      },
    })

    return steps
  }

  private complementDFA(): any[] {
    const steps: any[] = []

    steps.push({
      description: "Create DFA complement",
      explanation: "Swap accepting and non-accepting states",
      intermediateResult: this.automaton,
    })

    const complementAcceptStates = this.automaton.states.filter(
      (state: string) => !this.automaton.acceptStates.includes(state),
    )

    steps.push({
      description: "Complement construction complete",
      explanation: `New accept states: ${complementAcceptStates.join(", ")}`,
      result: {
        states: this.automaton.states,
        alphabet: this.automaton.alphabet,
        startState: this.automaton.startState,
        acceptStates: complementAcceptStates,
        transitions: this.automaton.transitions,
      },
      intermediateResult: {
        states: this.automaton.states,
        alphabet: this.automaton.alphabet,
        startState: this.automaton.startState,
        acceptStates: complementAcceptStates,
        transitions: this.automaton.transitions,
      },
    })

    return steps
  }

  // Keep existing methods (convertNFAToDFA, convertENFAToNFA, convertENFAToDFA)
  private convertNFAToDFA(): any[] {
    const steps: any[] = []
    const alphabet = this.automaton.alphabet.filter((s: string) => s !== "")
    const dfaStates: string[] = []
    const dfaTransitions: { [key: string]: { [key: string]: string } } = {}
    const dfaAcceptStates: string[] = []
    const stateQueue: string[][] = []
    const processedStates = new Set<string>()

    // Step 1: Initialize with start state
    const startStateSet = [this.automaton.startState]
    const startStateName = `{${startStateSet.join(",")}}`
    dfaStates.push(startStateName)
    stateQueue.push(startStateSet)

    if (startStateSet.some((s) => this.automaton.acceptStates.includes(s))) {
      dfaAcceptStates.push(startStateName)
    }

    steps.push({
      description: "Initialize DFA with start state",
      explanation: `Create initial DFA state from NFA start state: ${this.automaton.startState}`,
      intermediateResult: {
        states: [startStateName],
        alphabet: alphabet,
        startState: startStateName,
        acceptStates: dfaAcceptStates.slice(),
        transitions: {},
      },
      highlightedStates: [startStateName],
      newStates: [startStateName],
    })

    // Step 2: Process each state
    while (stateQueue.length > 0) {
      const currentStateSet = stateQueue.shift()!
      const currentStateName = `{${currentStateSet.join(",")}}`

      if (processedStates.has(currentStateName)) continue
      processedStates.add(currentStateName)

      dfaTransitions[currentStateName] = {}

      for (const symbol of alphabet) {
        const nextStates = new Set<string>()

        // Find all states reachable by this symbol
        for (const state of currentStateSet) {
          const transitions = this.automaton.transitions[state]?.[symbol]
          if (transitions) {
            const stateArray = Array.isArray(transitions) ? transitions : [transitions]
            stateArray.forEach((s: string) => nextStates.add(s))
          }
        }

        if (nextStates.size > 0) {
          const nextStateArray = Array.from(nextStates).sort()
          const nextStateName = `{${nextStateArray.join(",")}}`

          dfaTransitions[currentStateName][symbol] = nextStateName

          if (!dfaStates.includes(nextStateName)) {
            dfaStates.push(nextStateName)
            stateQueue.push(nextStateArray)

            if (nextStateArray.some((s) => this.automaton.acceptStates.includes(s))) {
              dfaAcceptStates.push(nextStateName)
            }
          }

          steps.push({
            description: `Process transition from ${currentStateName} on symbol '${symbol}'`,
            explanation: `From states ${currentStateSet.join(", ")}, symbol '${symbol}' leads to states ${nextStateArray.join(", ")}`,
            intermediateResult: {
              states: dfaStates.slice(),
              alphabet: alphabet,
              startState: startStateName,
              acceptStates: dfaAcceptStates.slice(),
              transitions: JSON.parse(JSON.stringify(dfaTransitions)),
            },
            highlightedStates: [currentStateName, nextStateName],
            highlightedTransitions: [`${currentStateName}-${symbol}-${nextStateName}`],
            newStates: dfaStates.includes(nextStateName) ? [] : [nextStateName],
          })
        }
      }
    }

    // Final step
    steps.push({
      description: "DFA conversion complete",
      explanation: "All NFA states have been processed and the equivalent DFA has been constructed",
      result: {
        states: dfaStates,
        alphabet: alphabet,
        startState: startStateName,
        acceptStates: dfaAcceptStates,
        transitions: dfaTransitions,
      },
      intermediateResult: {
        states: dfaStates,
        alphabet: alphabet,
        startState: startStateName,
        acceptStates: dfaAcceptStates,
        transitions: dfaTransitions,
      },
    })

    return steps
  }

  private convertENFAToNFA(): any[] {
    const steps: any[] = []
    const alphabet = this.automaton.alphabet.filter((s: string) => s !== "")
    const nfaStates = [...this.automaton.states]
    const nfaTransitions: { [key: string]: { [key: string]: string[] } } = {}
    const nfaAcceptStates = [...this.automaton.acceptStates]

    // Initialize transitions
    for (const state of nfaStates) {
      nfaTransitions[state] = {}
      for (const symbol of alphabet) {
        nfaTransitions[state][symbol] = []
      }
    }

    steps.push({
      description: "Initialize NFA structure",
      explanation: "Create NFA with same states but without ε-transitions",
      intermediateResult: {
        states: nfaStates,
        alphabet: alphabet,
        startState: this.automaton.startState,
        acceptStates: nfaAcceptStates,
        transitions: JSON.parse(JSON.stringify(nfaTransitions)),
      },
    })

    // Compute ε-closure for each state
    const epsilonClosure = (state: string): Set<string> => {
      const closure = new Set<string>([state])
      const stack = [state]

      while (stack.length > 0) {
        const current = stack.pop()!
        const epsilonTransitions = this.automaton.transitions[current]?.[""] || []
        const transitionArray = Array.isArray(epsilonTransitions) ? epsilonTransitions : [epsilonTransitions]

        for (const nextState of transitionArray) {
          if (nextState && !closure.has(nextState)) {
            closure.add(nextState)
            stack.push(nextState)
          }
        }
      }

      return closure
    }

    // Process each state and symbol
    for (const state of nfaStates) {
      const stateClosure = epsilonClosure(state)

      for (const symbol of alphabet) {
        const reachableStates = new Set<string>()

        for (const closureState of stateClosure) {
          const transitions = this.automaton.transitions[closureState]?.[symbol]
          if (transitions) {
            const transitionArray = Array.isArray(transitions) ? transitions : [transitions]
            for (const nextState of transitionArray) {
              if (nextState) {
                const nextClosure = epsilonClosure(nextState)
                nextClosure.forEach((s) => reachableStates.add(s))
              }
            }
          }
        }

        nfaTransitions[state][symbol] = Array.from(reachableStates).sort()

        if (reachableStates.size > 0) {
          steps.push({
            description: `Compute transitions for state ${state} on symbol '${symbol}'`,
            explanation: `ε-closure(${state}) = {${Array.from(stateClosure).join(", ")}}. On '${symbol}': {${Array.from(reachableStates).join(", ")}}`,
            intermediateResult: {
              states: nfaStates,
              alphabet: alphabet,
              startState: this.automaton.startState,
              acceptStates: nfaAcceptStates,
              transitions: JSON.parse(JSON.stringify(nfaTransitions)),
            },
            highlightedStates: [state, ...Array.from(reachableStates)],
          })
        }
      }
    }

    steps.push({
      description: "ε-NFA to NFA conversion complete",
      explanation: "All ε-transitions have been eliminated by computing ε-closures",
      result: {
        states: nfaStates,
        alphabet: alphabet,
        startState: this.automaton.startState,
        acceptStates: nfaAcceptStates,
        transitions: nfaTransitions,
      },
      intermediateResult: {
        states: nfaStates,
        alphabet: alphabet,
        startState: this.automaton.startState,
        acceptStates: nfaAcceptStates,
        transitions: nfaTransitions,
      },
    })

    return steps
  }

  private convertENFAToDFA(): any[] {
    // First convert ε-NFA to NFA, then NFA to DFA
    const enfaToNfaSteps = this.convertENFAToNFA()
    const nfa = enfaToNfaSteps[enfaToNfaSteps.length - 1].result

    // Create temporary converter for NFA to DFA
    const nfaConverter = new AutomataConverter(nfa, "nfa-to-dfa")
    const nfaToDfaSteps = nfaConverter.convertNFAToDFA()

    // Combine steps
    return [
      ...enfaToNfaSteps.slice(0, -1), // Remove final step from ε-NFA to NFA
      {
        description: "ε-NFA to NFA conversion complete, starting NFA to DFA conversion",
        explanation: "Now converting the resulting NFA to DFA using subset construction",
        intermediateResult: nfa,
      },
      ...nfaToDfaSteps,
    ]
  }
}
