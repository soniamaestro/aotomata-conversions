"use client"

import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { ChevronLeft, ChevronRight, SkipForward, RotateCcw } from "lucide-react"

interface StepControlsProps {
  currentStep: number
  totalSteps: number
  onNext: () => void
  onPrev: () => void
  onReset: () => void
  onAutoComplete: () => void
}

export function StepControls({ currentStep, totalSteps, onNext, onPrev, onReset, onAutoComplete }: StepControlsProps) {
  const progress = totalSteps > 0 ? ((currentStep + 1) / totalSteps) * 100 : 0

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-sm text-gray-600">
        <span>
          Step {currentStep + 1} of {totalSteps}
        </span>
        <span>{Math.round(progress)}% Complete</span>
      </div>

      <Progress value={progress} className="w-full" />

      <div className="grid grid-cols-2 gap-2">
        <Button variant="outline" size="sm" onClick={onPrev} disabled={currentStep === 0}>
          <ChevronLeft className="w-4 h-4 mr-1" />
          Previous
        </Button>

        <Button variant="outline" size="sm" onClick={onNext} disabled={currentStep >= totalSteps - 1}>
          Next
          <ChevronRight className="w-4 h-4 ml-1" />
        </Button>

        <Button variant="outline" size="sm" onClick={onAutoComplete} disabled={currentStep >= totalSteps - 1}>
          <SkipForward className="w-4 h-4 mr-1" />
          Complete
        </Button>

        <Button variant="outline" size="sm" onClick={onReset}>
          <RotateCcw className="w-4 h-4 mr-1" />
          Reset
        </Button>
      </div>
    </div>
  )
}
