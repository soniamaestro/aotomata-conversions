"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

interface TransitionTableProps {
  automaton: any
  highlightedStates?: string[]
}

export function TransitionTable({ automaton, highlightedStates = [] }: TransitionTableProps) {
  if (!automaton) return null

  const alphabet = automaton.alphabet || []
  const states = automaton.states || []
  const transitions = automaton.transitions || {}

  return (
    <div className="overflow-auto max-h-96">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="font-bold">State</TableHead>
            {alphabet.map((symbol: string) => (
              <TableHead key={symbol} className="font-bold text-center">
                {symbol === "" ? "ε" : symbol}
              </TableHead>
            ))}
            <TableHead className="font-bold text-center">Type</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {states.map((state: string) => (
            <TableRow key={state} className={highlightedStates.includes(state) ? "bg-yellow-100" : ""}>
              <TableCell className="font-medium">
                <div className="flex items-center gap-2">
                  {state}
                  {automaton.startState === state && (
                    <Badge variant="outline" className="text-xs">
                      Start
                    </Badge>
                  )}
                </div>
              </TableCell>
              {alphabet.map((symbol: string) => {
                const transition = transitions[state]?.[symbol]
                const transitionStates = Array.isArray(transition) ? transition : transition ? [transition] : []

                return (
                  <TableCell key={symbol} className="text-center">
                    {transitionStates.length > 0 ? (
                      <div className="flex flex-wrap gap-1 justify-center">
                        {transitionStates.map((toState: string, idx: number) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {toState}
                          </Badge>
                        ))}
                      </div>
                    ) : (
                      <span className="text-gray-400">∅</span>
                    )}
                  </TableCell>
                )
              })}
              <TableCell className="text-center">
                <div className="flex flex-wrap gap-1 justify-center">
                  {automaton.acceptStates.includes(state) && (
                    <Badge variant="destructive" className="text-xs">
                      Accept
                    </Badge>
                  )}
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
