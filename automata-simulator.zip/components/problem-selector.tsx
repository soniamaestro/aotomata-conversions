"use client"

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { predefinedProblems } from "@/lib/predefined-problems"

interface ProblemSelectorProps {
  mode: string
  selectedProblem: string
  onProblemChange: (problem: string) => void
}

export function ProblemSelector({ mode, selectedProblem, onProblemChange }: ProblemSelectorProps) {
  const problems = predefinedProblems[mode] || []

  return (
    <Select value={selectedProblem} onValueChange={onProblemChange} disabled={!mode}>
      <SelectTrigger>
        <SelectValue placeholder="Select a problem" />
      </SelectTrigger>
      <SelectContent>
        {problems.map((problem) => (
          <SelectItem key={problem.id} value={problem.id}>
            {problem.name}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}
