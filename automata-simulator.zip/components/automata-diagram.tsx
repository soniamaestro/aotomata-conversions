"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { ZoomIn, ZoomOut, RotateCcw } from "lucide-react"

interface AutomataDiagramProps {
  automaton: any
  highlightedStates?: string[]
  highlightedTransitions?: string[]
}

export function AutomataDiagram({
  automaton,
  highlightedStates = [],
  highlightedTransitions = [],
}: AutomataDiagramProps) {
  const svgRef = useRef<SVGSVGElement>(null)
  const [selectedState, setSelectedState] = useState<string | null>(null)
  const [zoom, setZoom] = useState(1)
  const [pan, setPan] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })

  useEffect(() => {
    if (!automaton) return
    renderDiagram()
  }, [automaton, highlightedStates, highlightedTransitions, zoom, pan])

  const renderDiagram = () => {
    if (!svgRef.current || !automaton) return

    const svg = svgRef.current
    svg.innerHTML = ""

    const width = 800
    const height = 600
    const centerX = width / 2
    const centerY = height / 2
    const radius = Math.min(width, height) * 0.25

    // Position states in an optimized layout
    const statePositions: { [key: string]: { x: number; y: number } } = {}
    const numStates = automaton.states.length

    if (numStates === 1) {
      statePositions[automaton.states[0]] = { x: centerX, y: centerY }
    } else if (numStates === 2) {
      statePositions[automaton.states[0]] = { x: centerX - 100, y: centerY }
      statePositions[automaton.states[1]] = { x: centerX + 100, y: centerY }
    } else if (numStates <= 6) {
      // Circular layout for small numbers
      automaton.states.forEach((state: string, index: number) => {
        const angle = (2 * Math.PI * index) / numStates - Math.PI / 2
        statePositions[state] = {
          x: centerX + radius * Math.cos(angle),
          y: centerY + radius * Math.sin(angle),
        }
      })
    } else {
      // Grid layout for larger numbers
      const cols = Math.ceil(Math.sqrt(numStates))
      const rows = Math.ceil(numStates / cols)
      const spacingX = (width * 0.8) / (cols + 1)
      const spacingY = (height * 0.8) / (rows + 1)
      const startX = width * 0.1 + spacingX
      const startY = height * 0.1 + spacingY

      automaton.states.forEach((state: string, index: number) => {
        const row = Math.floor(index / cols)
        const col = index % cols
        statePositions[state] = {
          x: startX + col * spacingX,
          y: startY + row * spacingY,
        }
      })
    }

    // Create defs for arrowheads and patterns
    const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs")

    // Regular arrowhead
    const arrowhead = document.createElementNS("http://www.w3.org/2000/svg", "marker")
    arrowhead.setAttribute("id", "arrowhead")
    arrowhead.setAttribute("markerWidth", "12")
    arrowhead.setAttribute("markerHeight", "8")
    arrowhead.setAttribute("refX", "11")
    arrowhead.setAttribute("refY", "4")
    arrowhead.setAttribute("orient", "auto")
    arrowhead.setAttribute("markerUnits", "strokeWidth")

    const arrowPath = document.createElementNS("http://www.w3.org/2000/svg", "path")
    arrowPath.setAttribute("d", "M 0 0 L 12 4 L 0 8 Z")
    arrowPath.setAttribute("fill", "#374151")
    arrowhead.appendChild(arrowPath)
    defs.appendChild(arrowhead)

    // Highlighted arrowhead
    const highlightedArrowhead = document.createElementNS("http://www.w3.org/2000/svg", "marker")
    highlightedArrowhead.setAttribute("id", "highlighted-arrowhead")
    highlightedArrowhead.setAttribute("markerWidth", "12")
    highlightedArrowhead.setAttribute("markerHeight", "8")
    highlightedArrowhead.setAttribute("refX", "11")
    highlightedArrowhead.setAttribute("refY", "4")
    highlightedArrowhead.setAttribute("orient", "auto")
    highlightedArrowhead.setAttribute("markerUnits", "strokeWidth")

    const highlightedArrowPath = document.createElementNS("http://www.w3.org/2000/svg", "path")
    highlightedArrowPath.setAttribute("d", "M 0 0 L 12 4 L 0 8 Z")
    highlightedArrowPath.setAttribute("fill", "#f59e0b")
    highlightedArrowhead.appendChild(highlightedArrowPath)
    defs.appendChild(highlightedArrowhead)

    svg.appendChild(defs)

    // Create group for transformations
    const g = document.createElementNS("http://www.w3.org/2000/svg", "g")
    g.setAttribute("transform", `translate(${pan.x}, ${pan.y}) scale(${zoom})`)
    svg.appendChild(g)

    // Group transitions by state pairs to handle multiple symbols
    const transitionGroups: { [key: string]: { symbols: string[]; isHighlighted: boolean } } = {}

    Object.entries(automaton.transitions).forEach(([fromState, transitions]: [string, any]) => {
      Object.entries(transitions).forEach(([symbol, toStates]: [string, any]) => {
        const toStateArray = Array.isArray(toStates) ? toStates : [toStates]
        toStateArray.forEach((toState: string) => {
          if (toState && statePositions[fromState] && statePositions[toState]) {
            const key = `${fromState}-${toState}`
            if (!transitionGroups[key]) {
              transitionGroups[key] = { symbols: [], isHighlighted: false }
            }
            transitionGroups[key].symbols.push(symbol === "" ? "ε" : symbol)
            if (highlightedTransitions.includes(`${fromState}-${symbol}-${toState}`)) {
              transitionGroups[key].isHighlighted = true
            }
          }
        })
      })
    })

    // Draw transitions with perfect arrows
    Object.entries(transitionGroups).forEach(([key, group]) => {
      const [fromState, toState] = key.split("-")
      drawPerfectTransition(g, fromState, toState, group.symbols.join(","), statePositions, group.isHighlighted)
    })

    // Draw states
    automaton.states.forEach((state: string) => {
      const pos = statePositions[state]
      if (pos) {
        drawPerfectState(g, state, pos.x, pos.y, {
          isStart: state === automaton.startState,
          isAccept: automaton.acceptStates.includes(state),
          isHighlighted: highlightedStates.includes(state),
          isSelected: selectedState === state,
        })
      }
    })
  }

  const drawPerfectState = (parent: SVGElement, state: string, x: number, y: number, options: any) => {
    const group = document.createElementNS("http://www.w3.org/2000/svg", "g")
    group.setAttribute("cursor", "pointer")

    // State circle with gradient
    const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle")
    circle.setAttribute("cx", x.toString())
    circle.setAttribute("cy", y.toString())
    circle.setAttribute("r", "30")

    let fillColor = "#f8fafc"
    if (options.isHighlighted) fillColor = "#fef3c7"
    else if (options.isSelected) fillColor = "#dbeafe"

    circle.setAttribute("fill", fillColor)
    circle.setAttribute("stroke", options.isAccept ? "#dc2626" : "#475569")
    circle.setAttribute("stroke-width", options.isAccept ? "3" : "2")
    circle.setAttribute("filter", "drop-shadow(2px 2px 4px rgba(0,0,0,0.1))")

    // Double circle for accept states
    if (options.isAccept) {
      const innerCircle = document.createElementNS("http://www.w3.org/2000/svg", "circle")
      innerCircle.setAttribute("cx", x.toString())
      innerCircle.setAttribute("cy", y.toString())
      innerCircle.setAttribute("r", "24")
      innerCircle.setAttribute("fill", "none")
      innerCircle.setAttribute("stroke", "#dc2626")
      innerCircle.setAttribute("stroke-width", "2")
      group.appendChild(innerCircle)
    }

    // Start arrow with perfect positioning
    if (options.isStart) {
      const arrowGroup = document.createElementNS("http://www.w3.org/2000/svg", "g")

      const arrowLine = document.createElementNS("http://www.w3.org/2000/svg", "line")
      arrowLine.setAttribute("x1", (x - 70).toString())
      arrowLine.setAttribute("y1", y.toString())
      arrowLine.setAttribute("x2", (x - 35).toString())
      arrowLine.setAttribute("y2", y.toString())
      arrowLine.setAttribute("stroke", "#374151")
      arrowLine.setAttribute("stroke-width", "2")
      arrowLine.setAttribute("marker-end", "url(#arrowhead)")

      const startLabel = document.createElementNS("http://www.w3.org/2000/svg", "text")
      startLabel.setAttribute("x", (x - 85).toString())
      startLabel.setAttribute("y", (y + 5).toString())
      startLabel.setAttribute("text-anchor", "middle")
      startLabel.setAttribute("font-family", "Arial, sans-serif")
      startLabel.setAttribute("font-size", "12")
      startLabel.setAttribute("fill", "#374151")
      startLabel.textContent = "start"

      arrowGroup.appendChild(arrowLine)
      arrowGroup.appendChild(startLabel)
      group.appendChild(arrowGroup)
    }

    group.appendChild(circle)

    // State label with better typography
    const text = document.createElementNS("http://www.w3.org/2000/svg", "text")
    text.setAttribute("x", x.toString())
    text.setAttribute("y", (y + 6).toString())
    text.setAttribute("text-anchor", "middle")
    text.setAttribute("font-family", "system-ui, -apple-system, sans-serif")
    text.setAttribute("font-size", "16")
    text.setAttribute("font-weight", "600")
    text.setAttribute("fill", "#1f2937")
    text.textContent = state
    group.appendChild(text)

    // Click handler
    group.addEventListener("click", (e) => {
      e.stopPropagation()
      setSelectedState(selectedState === state ? null : state)
    })

    parent.appendChild(group)
  }

  const drawPerfectTransition = (
    parent: SVGElement,
    from: string,
    to: string,
    symbols: string,
    positions: any,
    isHighlighted: boolean,
  ) => {
    const fromPos = positions[from]
    const toPos = positions[to]
    const strokeColor = isHighlighted ? "#f59e0b" : "#475569"
    const strokeWidth = isHighlighted ? "3" : "2"
    const markerEnd = isHighlighted ? "url(#highlighted-arrowhead)" : "url(#arrowhead)"

    if (from === to) {
      // Perfect self-loop
      const loopGroup = document.createElementNS("http://www.w3.org/2000/svg", "g")

      const path = document.createElementNS("http://www.w3.org/2000/svg", "path")
      const loopRadius = 25
      const startAngle = -Math.PI / 4
      const endAngle = Math.PI / 4

      const startX = fromPos.x + 30 * Math.cos(startAngle)
      const startY = fromPos.y + 30 * Math.sin(startAngle)
      const endX = fromPos.x + 30 * Math.cos(endAngle)
      const endY = fromPos.y + 30 * Math.sin(endAngle)

      const controlX = fromPos.x + 60
      const controlY = fromPos.y - 40

      const d = `M ${startX} ${startY} Q ${controlX} ${controlY} ${endX} ${endY}`
      path.setAttribute("d", d)
      path.setAttribute("fill", "none")
      path.setAttribute("stroke", strokeColor)
      path.setAttribute("stroke-width", strokeWidth)
      path.setAttribute("marker-end", markerEnd)

      const text = document.createElementNS("http://www.w3.org/2000/svg", "text")
      text.setAttribute("x", controlX.toString())
      text.setAttribute("y", (controlY - 5).toString())
      text.setAttribute("text-anchor", "middle")
      text.setAttribute("font-family", "system-ui, -apple-system, sans-serif")
      text.setAttribute("font-size", "14")
      text.setAttribute("font-weight", "500")
      text.setAttribute("fill", strokeColor)
      text.textContent = symbols

      loopGroup.appendChild(path)
      loopGroup.appendChild(text)
      parent.appendChild(loopGroup)
    } else {
      // Perfect straight or curved transition
      const dx = toPos.x - fromPos.x
      const dy = toPos.y - fromPos.y
      const distance = Math.sqrt(dx * dx + dy * dy)
      const unitX = dx / distance
      const unitY = dy / distance

      // Calculate start and end points on circle edges
      const startX = fromPos.x + 30 * unitX
      const startY = fromPos.y + 30 * unitY
      const endX = toPos.x - 30 * unitX
      const endY = toPos.y - 30 * unitY

      // Check if there's a reverse transition to create curved arrows
      const hasReverse = Object.entries(automaton.transitions).some(([state, trans]: [string, any]) => {
        if (state === to) {
          return Object.values(trans).some((targets: any) => {
            const targetArray = Array.isArray(targets) ? targets : [targets]
            return targetArray.includes(from)
          })
        }
        return false
      })

      if (hasReverse && from < to) {
        // Create curved path for bidirectional transitions
        const midX = (startX + endX) / 2
        const midY = (startY + endY) / 2
        const perpX = -unitY * 30
        const perpY = unitX * 30
        const controlX = midX + perpX
        const controlY = midY + perpY

        const path = document.createElementNS("http://www.w3.org/2000/svg", "path")
        const d = `M ${startX} ${startY} Q ${controlX} ${controlY} ${endX} ${endY}`
        path.setAttribute("d", d)
        path.setAttribute("fill", "none")
        path.setAttribute("stroke", strokeColor)
        path.setAttribute("stroke-width", strokeWidth)
        path.setAttribute("marker-end", markerEnd)

        const text = document.createElementNS("http://www.w3.org/2000/svg", "text")
        text.setAttribute("x", controlX.toString())
        text.setAttribute("y", (controlY - 5).toString())
        text.setAttribute("text-anchor", "middle")
        text.setAttribute("font-family", "system-ui, -apple-system, sans-serif")
        text.setAttribute("font-size", "14")
        text.setAttribute("font-weight", "500")
        text.setAttribute("fill", strokeColor)
        text.textContent = symbols

        parent.appendChild(path)
        parent.appendChild(text)
      } else if (!hasReverse || from > to) {
        // Straight line for unidirectional or second direction of bidirectional
        const line = document.createElementNS("http://www.w3.org/2000/svg", "line")
        line.setAttribute("x1", startX.toString())
        line.setAttribute("y1", startY.toString())
        line.setAttribute("x2", endX.toString())
        line.setAttribute("y2", endY.toString())
        line.setAttribute("stroke", strokeColor)
        line.setAttribute("stroke-width", strokeWidth)
        line.setAttribute("marker-end", markerEnd)

        const midX = (startX + endX) / 2
        const midY = (startY + endY) / 2

        // Offset text slightly for reverse direction
        const textOffsetX = hasReverse ? -unitY * 15 : 0
        const textOffsetY = hasReverse ? unitX * 15 : 0

        const text = document.createElementNS("http://www.w3.org/2000/svg", "text")
        text.setAttribute("x", (midX + textOffsetX).toString())
        text.setAttribute("y", (midY + textOffsetY - 5).toString())
        text.setAttribute("text-anchor", "middle")
        text.setAttribute("font-family", "system-ui, -apple-system, sans-serif")
        text.setAttribute("font-size", "14")
        text.setAttribute("font-weight", "500")
        text.setAttribute("fill", strokeColor)
        text.textContent = symbols

        parent.appendChild(line)
        parent.appendChild(text)
      }
    }
  }

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true)
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y })
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPan({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      })
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const handleZoomIn = () => setZoom(Math.min(zoom * 1.2, 3))
  const handleZoomOut = () => setZoom(Math.max(zoom / 1.2, 0.3))
  const handleReset = () => {
    setZoom(1)
    setPan({ x: 0, y: 0 })
    setSelectedState(null)
  }

  return (
    <div className="relative">
      <div className="absolute top-2 right-2 z-10 flex gap-2">
        <Button size="sm" variant="outline" onClick={handleZoomIn}>
          <ZoomIn className="w-4 h-4" />
        </Button>
        <Button size="sm" variant="outline" onClick={handleZoomOut}>
          <ZoomOut className="w-4 h-4" />
        </Button>
        <Button size="sm" variant="outline" onClick={handleReset}>
          <RotateCcw className="w-4 h-4" />
        </Button>
      </div>

      <svg
        ref={svgRef}
        width="100%"
        height="600"
        viewBox="0 0 800 600"
        className="border rounded-lg bg-gradient-to-br from-slate-50 to-blue-50 cursor-move"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      />

      {selectedState && (
        <div className="absolute bottom-2 left-2 bg-white p-3 rounded-lg shadow-lg border max-w-xs">
          <h4 className="font-semibold text-lg mb-2">State: {selectedState}</h4>
          <div className="space-y-1 text-sm">
            {automaton.startState === selectedState && (
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span>Start state</span>
              </div>
            )}
            {automaton.acceptStates.includes(selectedState) && (
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <span>Accept state</span>
              </div>
            )}
            <div className="mt-2 pt-2 border-t">
              <span className="font-medium">Transitions:</span>
              <div className="mt-1">
                {Object.entries(automaton.transitions[selectedState] || {}).map(([symbol, targets]: [string, any]) => {
                  const targetArray = Array.isArray(targets) ? targets : [targets]
                  return (
                    <div key={symbol} className="text-xs">
                      <span className="font-mono bg-gray-100 px-1 rounded">{symbol === "" ? "ε" : symbol}</span>
                      {" → "}
                      {targetArray.filter(Boolean).join(", ") || "∅"}
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
