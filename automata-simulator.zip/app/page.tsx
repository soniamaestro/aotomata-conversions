"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Play, Info } from "lucide-react"
import { AutomataConverter } from "@/lib/automata-converter"
import { AutomataDiagram } from "@/components/automata-diagram"
import { TransitionTable } from "@/components/transition-table"
import { StepControls } from "@/components/step-controls"
import { ProblemSelector } from "@/components/problem-selector"
import { predefinedProblems } from "@/lib/predefined-problems"

export default function AutomataSimulator() {
  const [mode, setMode] = useState<string>("")
  const [selectedProblem, setSelectedProblem] = useState<string>("")
  const [originalAutomaton, setOriginalAutomaton] = useState<any>(null)
  const [converter, setConverter] = useState<AutomataConverter | null>(null)
  const [currentStep, setCurrentStep] = useState(0)
  const [isConverting, setIsConverting] = useState(false)
  const [conversionSteps, setConversionSteps] = useState<any[]>([])
  const [finalResult, setFinalResult] = useState<any>(null)

  const modes = [
    { value: "nfa-to-dfa", label: "NFA → DFA" },
    { value: "enfa-to-nfa", label: "ε-NFA → NFA" },
    { value: "enfa-to-dfa", label: "ε-NFA → DFA" },
    { value: "dfa-to-nfa", label: "DFA → NFA" },
    { value: "dfa-minimize", label: "DFA Minimization" },
    { value: "regex-to-nfa", label: "RegEx → NFA" },
    { value: "nfa-to-regex", label: "NFA → RegEx" },
    { value: "dfa-to-regex", label: "DFA → RegEx" },
    { value: "nfa-to-enfa", label: "NFA → ε-NFA" },
    { value: "complement-dfa", label: "DFA Complement" },
  ]

  useEffect(() => {
    if (mode && selectedProblem) {
      const problem = predefinedProblems[mode]?.find((p) => p.id === selectedProblem)
      if (problem) {
        setOriginalAutomaton(problem.automaton)
        setConverter(new AutomataConverter(problem.automaton, mode))
        setCurrentStep(0)
        setConversionSteps([])
        setFinalResult(null)
        setIsConverting(false)
      }
    }
  }, [mode, selectedProblem])

  const startConversion = () => {
    if (!converter) return

    setIsConverting(true)
    const steps = converter.getConversionSteps()
    setConversionSteps(steps)
    setCurrentStep(0)
    setFinalResult(steps[steps.length - 1]?.result || null)
  }

  const nextStep = () => {
    if (currentStep < conversionSteps.length - 1) {
      setCurrentStep(currentStep + 1)
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const resetConversion = () => {
    setCurrentStep(0)
    setIsConverting(false)
    setConversionSteps([])
    setFinalResult(null)
  }

  const autoComplete = () => {
    if (conversionSteps.length > 0) {
      setCurrentStep(conversionSteps.length - 1)
    }
  }

  const getCurrentAutomaton = () => {
    if (!isConverting || conversionSteps.length === 0) {
      return originalAutomaton
    }
    return conversionSteps[currentStep]?.intermediateResult || originalAutomaton
  }

  const getCurrentStepInfo = () => {
    if (!isConverting || conversionSteps.length === 0) return null
    return conversionSteps[currentStep]
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <Card>
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-center text-indigo-800">
              Multi-Mode Automata Conversion Simulator
            </CardTitle>
            <p className="text-center text-gray-600">
              Interactive step-by-step automata conversion with live diagrams and transition tables
            </p>
          </CardHeader>
        </Card>

        {/* Controls */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Conversion Mode</CardTitle>
            </CardHeader>
            <CardContent>
              <Select value={mode} onValueChange={setMode}>
                <SelectTrigger>
                  <SelectValue placeholder="Select conversion mode" />
                </SelectTrigger>
                <SelectContent>
                  {modes.map((m) => (
                    <SelectItem key={m.value} value={m.value}>
                      {m.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Problem Selection</CardTitle>
            </CardHeader>
            <CardContent>
              <ProblemSelector mode={mode} selectedProblem={selectedProblem} onProblemChange={setSelectedProblem} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Conversion Controls</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {!isConverting ? (
                  <Button onClick={startConversion} disabled={!mode || !selectedProblem} className="w-full">
                    <Play className="w-4 h-4 mr-2" />
                    Start Conversion
                  </Button>
                ) : (
                  <StepControls
                    currentStep={currentStep}
                    totalSteps={conversionSteps.length}
                    onNext={nextStep}
                    onPrev={prevStep}
                    onReset={resetConversion}
                    onAutoComplete={autoComplete}
                  />
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Current Step Info */}
        {isConverting && getCurrentStepInfo() && (
          <Card className="border-l-4 border-l-blue-500">
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <Info className="w-5 h-5 mr-2" />
                Step {currentStep + 1} of {conversionSteps.length}: {getCurrentStepInfo().description}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700">{getCurrentStepInfo().explanation}</p>
              {getCurrentStepInfo().newStates && (
                <div className="mt-2">
                  <span className="font-semibold">New states created: </span>
                  {getCurrentStepInfo().newStates.map((state: string, idx: number) => (
                    <Badge key={idx} variant="secondary" className="ml-1">
                      {state}
                    </Badge>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Main Content */}
        {originalAutomaton && (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {/* Diagram */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">
                  {isConverting ? `${mode.toUpperCase()} Conversion - Step ${currentStep + 1}` : "Original Automaton"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <AutomataDiagram
                  automaton={getCurrentAutomaton()}
                  highlightedStates={getCurrentStepInfo()?.highlightedStates || []}
                  highlightedTransitions={getCurrentStepInfo()?.highlightedTransitions || []}
                />
              </CardContent>
            </Card>

            {/* Transition Table */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Transition Table</CardTitle>
              </CardHeader>
              <CardContent>
                <TransitionTable
                  automaton={getCurrentAutomaton()}
                  highlightedStates={getCurrentStepInfo()?.highlightedStates || []}
                />
              </CardContent>
            </Card>
          </div>
        )}

        {/* Final Result */}
        {finalResult && currentStep === conversionSteps.length - 1 && (
          <Card className="border-2 border-green-500">
            <CardHeader>
              <CardTitle className="text-lg text-green-700">Conversion Complete!</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <p>
                  <strong>Original states:</strong> {originalAutomaton.states.length}
                </p>
                <p>
                  <strong>Final states:</strong> {finalResult.states.length}
                </p>
                <p>
                  <strong>Alphabet:</strong> {finalResult.alphabet.join(", ")}
                </p>
                <p>
                  <strong>Start state:</strong> {finalResult.startState}
                </p>
                <p>
                  <strong>Accept states:</strong> {finalResult.acceptStates.join(", ")}
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
